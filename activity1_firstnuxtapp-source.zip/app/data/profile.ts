/**
 * All of the website's personal content lives in this one file.
 * Replace the placeholder values below with your own details —
 * both pages update automatically.
 */

export const profile = {
  name: 'Your Name',
  initials: 'YN',
  tagline: 'BS Information Technology Student',
  avatar: '/images/avatar.svg',

  intro:
    'Write a short introduction about yourself here — who you are, what you are studying, and what you are passionate about. Two or three sentences work best.',

  welcome:
    'Thanks for stopping by! This site is a small corner of the web where you can get to know me — my studies, my skills, and the things I enjoy doing.',

  personalInfo: [
    { label: 'Full Name', value: 'Your Full Name' },
    { label: 'Age', value: 'Your Age' },
    { label: 'Location', value: 'Your City, Country' },
    { label: 'Nationality', value: 'Your Nationality' },
    { label: 'Languages', value: 'Languages You Speak' },
    { label: 'Email', value: 'your.email@example.com' }
  ],

  education: [
    {
      level: 'College',
      school: 'Your University Name',
      program: 'Bachelor of Science in Information Technology',
      details: '3rd Year · Expected graduation year',
      current: true
    },
    {
      level: 'Senior High School',
      school: 'Your Senior High School',
      program: 'Your Strand / Track',
      details: 'Year started – Year graduated',
      current: false
    }
  ],

  // Tools used to build this website — add or remove as you learn more
  technicalSkills: ['HTML', 'CSS', 'JavaScript', 'Vue.js', 'Nuxt.js', 'Tailwind CSS', 'Git'],

  interests: ['Your Interest 1', 'Your Interest 2', 'Your Interest 3', 'Your Interest 4'],

  expertise: [
    { title: 'Area of Expertise 1', description: 'Describe a field or topic you are good at.' },
    { title: 'Area of Expertise 2', description: 'Describe another strength or focus area.' }
  ],

  // icon options: book, music, game, camera, ball, code
  hobbies: [
    { icon: 'book', title: 'Hobby 1', description: 'Describe an activity you enjoy and why you like it.' },
    { icon: 'music', title: 'Hobby 2', description: 'Describe an activity you enjoy and why you like it.' },
    { icon: 'game', title: 'Hobby 3', description: 'Describe an activity you enjoy and why you like it.' },
    { icon: 'camera', title: 'Hobby 4', description: 'Describe an activity you enjoy and why you like it.' }
  ]
}
